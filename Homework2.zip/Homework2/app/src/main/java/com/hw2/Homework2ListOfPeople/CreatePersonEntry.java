package com.hw2.Homework2ListOfPeople;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import static java.lang.Math.random;

public class CreatePersonEntry extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_person_entry);
    }

    public void submit(View view) {
        String PersonName = ((EditText)findViewById(R.id.newPersonName)).getText().toString();
        String PersonDateBirth = ((EditText)findViewById(R.id.newPersonDateBirth)).getText().toString();
        String PersonShortDescription = ((EditText)findViewById(R.id.newPersonShortDescription)).getText().toString();

        if ( PersonName.isEmpty() )
            PersonName = getResources().getString(R.string.PersonName);
        if ( PersonDateBirth.isEmpty() )
            PersonDateBirth = getResources().getString(R.string.PersonDateBirth);
        if ( PersonShortDescription.isEmpty() )
            PersonShortDescription = getResources().getString(R.string.PersonShortDescription);

        String PersonPic = "pic" + (int)(  1 + random() * 5 );
        int PersonPicID = getResources().getIdentifier(PersonPic, "drawable", getPackageName() );
        Person tmp = new Person( PersonName, PersonDateBirth, PersonShortDescription, PersonPicID );
        MainActivity.myPeople.add(tmp);

        finish();
    }
}
