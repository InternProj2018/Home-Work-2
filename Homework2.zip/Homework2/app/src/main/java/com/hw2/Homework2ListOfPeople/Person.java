package com.hw2.Homework2ListOfPeople;

import android.os.Parcel;
import android.os.Parcelable;

public class Person implements Parcelable {
    public String Name_and_surname, Date_of_birth, Short_description;
    int picID;

    Person() {

    }

    Person( String n, String d ) {
        Name_and_surname = n;
        Date_of_birth = d;
        Short_description = null;
        picID = 0;
    }

    Person( String n, String d, String s ) {
        Name_and_surname = n;
        Date_of_birth = d;
        Short_description = s;
        picID = 0;
    }

    Person( String n, String d, String s, int pic ) {
        Name_and_surname = n;
        Date_of_birth = d;
        Short_description = s;
        picID = pic;
    }

    protected Person(Parcel in) {
        Name_and_surname = in.readString();
        Date_of_birth = in.readString();
        Short_description = in.readString();
        picID = in.readInt();
    }

    public static final Creator<Person> CREATOR = new Creator<Person>() {
        @Override
        public Person createFromParcel(Parcel in) {
            return new Person(in);
        }

        @Override
        public Person[] newArray(int size) {
            return new Person[size];
        }
    };

    @Override
    public String toString() {
        return Name_and_surname;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(Name_and_surname);
        dest.writeString(Date_of_birth);
        dest.writeString(Short_description);
        dest.writeInt(picID);
    }

}
