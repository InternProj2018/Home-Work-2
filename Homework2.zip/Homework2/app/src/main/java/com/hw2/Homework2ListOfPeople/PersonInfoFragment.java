package com.hw2.Homework2ListOfPeople;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;


/**
 * A simple {@link Fragment} subclass.
 */
public class PersonInfoFragment extends Fragment {
    public PersonInfoFragment() {
        // Required empty public constructor
    }

    @Override
    public void onActivityCreated( Bundle savedInstanceState ) {
        super.onActivityCreated(savedInstanceState);

        Intent intent = getActivity().getIntent();

        Person receivedTask = intent.getParcelableExtra( MainActivity.personExtra );
        if (receivedTask != null)
            displayTask(receivedTask);

    }

    @Override
    public View onCreateView( LayoutInflater inflater, ViewGroup container,
                              Bundle savedInstanceState ) {
        // Inflate the layout for this fragment
        return inflater.inflate( R.layout.fragment_person_info, container, false );
    }

    public void displayTask( Person person ) {
        ((TextView)getActivity().findViewById( R.id.PersonName  ) ).setText( person.Name_and_surname );
        ((TextView)getActivity().findViewById( R.id.PersonDateBirth ) ).setText( person.Date_of_birth );
        ((TextView)getActivity().findViewById( R.id.PersonShortDescription ) ).setText( person.Short_description );
        ImageView taskImage = (ImageView) getActivity().findViewById( R.id.PersonPic );
        if ( person.picID != 0 ) {
            taskImage.setImageResource(person.picID);
        } else {
            taskImage.setImageBitmap(null);
        }
    }
}
