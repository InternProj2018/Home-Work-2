package com.hw2.Homework2ListOfPeople;

import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.DialogFragment;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements DeleteDialog.NoticeDialogListener {

    public static final String PEOPLE_FILE = "com.nvwa.hw2.PeopleFile";
    public static final String NUM_PEOPLE = "NumOfPeople";
    public static final String NAME_AND_SURNAME = "name_and_surname_";
    public static final String DATE_OF_BIRTH = "date_of_birth_";
    public static final String SHORT_DESCRIPTION = "short_description_";
    public static final String PIC = "pic_";

    static public int selected_item = -1;
    public static final String personExtra = "Person";
    static public ArrayList<Person> myPeople;
    static {
        myPeople = new ArrayList<Person>();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        readDataFromFile();

        ListAdapter personListAdapter = new ArrayAdapter<Person>( this, android.R.layout.simple_list_item_1, android.R.id.text1, myPeople );
        ListView people = (ListView)findViewById(R.id.people);
        people.setAdapter(personListAdapter);

        FloatingActionButton addPerson = (FloatingActionButton) findViewById(R.id.addPerson);
        addPerson.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent( getApplicationContext(), CreatePersonEntry.class );
                startActivity(intent);
            }
        });

        if ( getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE ) {
            PersonInfoFragment frag = (PersonInfoFragment) getSupportFragmentManager().findFragmentById(R.id.personInfo);
            frag.displayTask( new Person("", "", "") );

            FloatingActionButton removePerson = (FloatingActionButton) findViewById(R.id.removePerson);
            removePerson.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    DialogFragment newFragment = DeleteDialog.newInstance();
                    newFragment.show( getSupportFragmentManager(), "DeleteDialogTag" );
                }
            });
        }

        people.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                selected_item = position;
                if ( getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE ) {
                    PersonInfoFragment frag = (PersonInfoFragment)getSupportFragmentManager().findFragmentById(R.id.personInfo);
                    frag.displayTask( (Person)parent.getItemAtPosition(position) );
                } else {
                    Intent intent = new Intent( getApplicationContext(), PersonActivity.class );
                    Person tmp = (Person) parent.getItemAtPosition(position);
                    intent.putExtra(personExtra, tmp);

                    startActivity(intent);
                }
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        ListAdapter personListAdapter = new ArrayAdapter<Person>( this, android.R.layout.simple_list_item_1, android.R.id.text1, myPeople );
        ListView people = (ListView)findViewById(R.id.people);
        people.setAdapter(personListAdapter);
        ((ArrayAdapter) personListAdapter).notifyDataSetChanged();
        saveDataToFile();
    }

    private void readDataFromFile() {
        myPeople.clear();
        String filename = "myPeople.txt";
        String delim = ";";
        FileInputStream inputStream;
        try {
            inputStream = openFileInput(filename);
            BufferedReader reader = new BufferedReader( new FileReader( inputStream.getFD() ) );
            String line;
            while ( (line = reader.readLine() ) != null ) {
                String PersonName = line.substring( 0, line.indexOf(delim) );
                line = line.substring( line.indexOf(delim) + 1 );
                String PersonDateBirth = line.substring( 0, line.indexOf(delim) );
                line = line.substring( line.indexOf(delim) + 1 );
                String PersonShortDescription = line.substring( 0, line.indexOf(delim) );
                line = line.substring( line.indexOf(delim) + 1 );
                Person tmp = new Person(PersonName, PersonDateBirth, PersonShortDescription, Integer.parseInt(line) );
                myPeople.add(tmp);
            }
        } catch(FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    private void saveDataToFile() {
        String filename = "myPeople.txt";
        FileOutputStream outputStream;

        try {
            outputStream = openFileOutput( filename, Context.MODE_PRIVATE );
            BufferedWriter writer = new BufferedWriter( new FileWriter( outputStream.getFD() ) );
            String delim = ";";

            for ( Integer i = 0; i < myPeople.size(); i++ ) {
                Person tmp = myPeople.get(i);
                String line = tmp.Name_and_surname + delim + tmp.Date_of_birth + delim + tmp.Short_description + delim + tmp.picID;
                writer.write( line );
                writer.newLine();
            }
            writer.close();
        } catch ( IOException ex ) {
            ex.printStackTrace();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onDialogPositiveClick(DialogFragment dialog) {
        myPeople.remove(selected_item);
        ListAdapter personListAdapter = new ArrayAdapter<Person>( this, android.R.layout.simple_list_item_1, android.R.id.text1, myPeople );
        ListView people = (ListView)findViewById(R.id.people);
        people.setAdapter(personListAdapter);
        ((ArrayAdapter) personListAdapter).notifyDataSetChanged();
        PersonInfoFragment frag = (PersonInfoFragment) getSupportFragmentManager().findFragmentById(R.id.personInfo);
        frag.displayTask( new Person("", "", "") );
    }

    @Override
    public void onDialogNegativeClick(DialogFragment dialog) {

    }
}
